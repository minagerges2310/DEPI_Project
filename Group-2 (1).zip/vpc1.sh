#!/bin/bash

# Create VPC
echo "Creating VPC..."
VPC_ID=$(aws ec2 create-vpc --cidr-block 10.0.0.0/16 --tag-specifications "ResourceType=vpc,Tags=[{Key=Name,Value='Lab VPC'}]" --query 'Vpc.VpcId' --output text)
echo "VPC ID: $VPC_ID"

# Enable DNS hostnames for the VPC
aws ec2 modify-vpc-attribute --vpc-id $VPC_ID --enable-dns-hostnames
echo "Enabled DNS hostnames for VPC: $VPC_ID"

# Create Public Subnet
echo "Creating Public Subnet..."
PUBLIC_SUBNET_ID=$(aws ec2 create-subnet --vpc-id $VPC_ID --cidr-block 10.0.0.0/24 --tag-specifications "ResourceType=subnet,Tags=[{Key=Name,Value='Public Subnet'}]" --query 'Subnet.SubnetId' --output text)
echo "Public Subnet ID: $PUBLIC_SUBNET_ID"

# Enable auto-assign public IP for the Public Subnet
aws ec2 modify-subnet-attribute --subnet-id $PUBLIC_SUBNET_ID --map-public-ip-on-launch
echo "Enabled auto-assign public IP for Subnet: $PUBLIC_SUBNET_ID"

# Create Private Subnet
echo "Creating Private Subnet..."
PRIVATE_SUBNET_ID=$(aws ec2 create-subnet --vpc-id $VPC_ID --cidr-block 10.0.2.0/23 --tag-specifications "ResourceType=subnet,Tags=[{Key=Name,Value='Private Subnet'}]" --query 'Subnet.SubnetId' --output text)
echo "Private Subnet ID: $PRIVATE_SUBNET_ID"

# Create Internet Gateway
echo "Creating Internet Gateway..."
IGW_ID=$(aws ec2 create-internet-gateway --tag-specifications "ResourceType=internet-gateway,Tags=[{Key=Name,Value='Lab IGW'}]" --query 'InternetGateway.InternetGatewayId' --output text)
echo "Internet Gateway ID: $IGW_ID"

# Attach Internet Gateway to the VPC
aws ec2 attach-internet-gateway --internet-gateway-id $IGW_ID --vpc-id $VPC_ID
echo "Attached Internet Gateway $IGW_ID to VPC: $VPC_ID"

# Create Route Table
echo "Creating Route Table..."
ROUTE_TABLE_ID=$(aws ec2 create-route-table --vpc-id $VPC_ID --tag-specifications "ResourceType=route-table,Tags=[{Key=Name,Value='Public Route Table'}]" --query 'RouteTable.RouteTableId' --output text)
echo "Route Table ID: $ROUTE_TABLE_ID"

# Create Route in the Route Table
aws ec2 create-route --route-table-id $ROUTE_TABLE_ID --destination-cidr-block 0.0.0.0/0 --gateway-id $IGW_ID
echo "Added route to Route Table: $ROUTE_TABLE_ID"

# Associate Route Table with Public Subnet
aws ec2 associate-route-table --route-table-id $ROUTE_TABLE_ID --subnet-id $PUBLIC_SUBNET_ID
echo "Associated Route Table $ROUTE_TABLE_ID with Subnet: $PUBLIC_SUBNET_ID"

# Create Security Group
echo "Creating Security Group..."
SECURITY_GROUP_ID=$(aws ec2 create-security-group --group-name App-SG --description "Allow HTTP traffic" --vpc-id $VPC_ID --tag-specifications "ResourceType=security-group,Tags=[{Key=Name,Value='App-SG'}]" --query 'GroupId' --output text)
echo "Security Group ID: $SECURITY_GROUP_ID"

# Allow HTTP traffic in the Security Group
aws ec2 authorize-security-group-ingress --group-id $SECURITY_GROUP_ID --protocol tcp --port 80 --cidr 0.0.0.0/0 --description "Allow web access"
echo "Allowed HTTP traffic in Security Group: $SECURITY_GROUP_ID"

# Launch EC2 Instance
echo "Launching EC2 instance..."
INSTANCE_ID=$(aws ec2 run-instances --image-id ami-0fff1b9a61dec8a5f --count 1 --instance-type t2.micro --key-name vockey --subnet-id $PUBLIC_SUBNET_ID --security-group-ids $SECURITY_GROUP_ID --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value='App Server'}]" --user-data '#!/bin/bash
dnf install -y httpd wget php-fpm php-mysqli php-json php php-devel
dnf install -y mariadb105-server
wget https://aws-tc-largeobjects.s3.us-west-2.amazonaws.com/CUR-TF-200-ACACAD-3-113230/06-lab-mod7-guided-VPC/s3/scripts/al2023-inventory-app.zip -O inventory-app.zip
unzip inventory-app.zip -d /var/www/html/
wget https://docs.aws.amazon.com/aws-sdk-php/v3/download/aws.zip
unzip aws.zip -d /var/www/html
systemctl enable httpd
systemctl start httpd' --query 'Instances[0].InstanceId' --output text)
echo "EC2 Instance ID: $INSTANCE_ID"

echo "All resources have been created successfully!"
